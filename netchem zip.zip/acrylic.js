// Example: countdown for offer validity
document.addEventListener("DOMContentLoaded", function() {
    let offerPriceElement = document.querySelector('.offer-price');
    let originalPrice = 450;
    let discount = 50; // 50 units discount
    let offerPrice = originalPrice - discount;
    offerPriceElement.textContent = offerPrice;
});